from setuptools import setup, find_packages

setup(
    name="wafer-fault-detection",
    version="0.0.3",
    description="ML project",
    author="Avnish yadav", 
    packages=find_packages(),
    license="MIT"
)