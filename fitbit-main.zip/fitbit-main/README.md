## create conda env with python 3.7 version

install requirements.txt file 




