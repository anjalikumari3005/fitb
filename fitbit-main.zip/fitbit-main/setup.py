from setuptools import setup, find_packages

setup(
    name="fitbit",
    version="0.0.3",
    description="fitbit",
    author="Avnish yadav", 
    packages=find_packages(),
    license="MIT"
)